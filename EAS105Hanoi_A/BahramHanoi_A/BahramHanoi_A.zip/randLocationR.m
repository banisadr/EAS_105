function [v] = randLocationR(n)
v = randi(3,1,n);
end